package com.example.ecommerce.medicare.exceptions;

public class UpdateProductException extends Exception {
	private static final long serialVersionUID = 1L;
}
