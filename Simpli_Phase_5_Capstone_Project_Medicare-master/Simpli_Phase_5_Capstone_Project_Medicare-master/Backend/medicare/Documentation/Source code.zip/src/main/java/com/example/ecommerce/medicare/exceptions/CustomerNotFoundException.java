package com.example.ecommerce.medicare.exceptions;

public class CustomerNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;
}
