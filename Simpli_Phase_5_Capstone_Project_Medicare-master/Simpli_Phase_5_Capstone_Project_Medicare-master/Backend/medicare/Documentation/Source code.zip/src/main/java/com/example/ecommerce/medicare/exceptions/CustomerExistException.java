package com.example.ecommerce.medicare.exceptions;

public class CustomerExistException extends Exception{
	private static final long serialVersionUID = 1L;
}
