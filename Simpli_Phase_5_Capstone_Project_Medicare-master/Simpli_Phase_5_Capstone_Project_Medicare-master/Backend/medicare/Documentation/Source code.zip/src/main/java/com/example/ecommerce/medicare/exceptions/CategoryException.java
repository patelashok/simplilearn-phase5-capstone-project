package com.example.ecommerce.medicare.exceptions;

public class CategoryException extends Exception {
	private static final long serialVersionUID = 1L;
}
