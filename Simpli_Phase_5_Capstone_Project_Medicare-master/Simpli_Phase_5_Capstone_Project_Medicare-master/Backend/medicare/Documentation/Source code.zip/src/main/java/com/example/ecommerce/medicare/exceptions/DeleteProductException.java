package com.example.ecommerce.medicare.exceptions;

public class DeleteProductException extends Exception {
	private static final long serialVersionUID = 1L;
}
