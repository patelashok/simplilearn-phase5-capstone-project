package com.example.ecommerce.medicare.exceptions;

public class ProductNotFound extends Exception{
	private static final long serialVersionUID = 1L;
}
